	angular.module('result.controller', [])
		.directive('resultPreview', function () {
			return {
				restrict: 'EA',
				scope: {
					result: '=show'
				},
				templateUrl: '../views/preview.html'
			}
		})
		.controller('ResultController', function ($scope, resultResource) {

			$scope.getResult = function () {
				resultResource.query({
					name: $scope.name
				}, function (response) {
					$scope.results = response;
				});	
			};

	});