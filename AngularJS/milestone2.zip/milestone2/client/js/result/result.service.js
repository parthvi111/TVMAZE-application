	angular.module('result.service', [])
		.factory('resultResource', function ($resource) {
			return $resource('/api/');
		});